Content of production file folders:

The folders contain:
/BOM/
	Bill of material file (*.xls)

/Gerber + Drill/
	Drill files (*.DRL, *.DRR & *.TXT)

	Gerber photo plot files:
		*.GBL :	Bottom layer copper
		*.GBO : Bottom silkscreen
		*.GBP : Bottom Pad master
		*.GBS : Bottom Solder mask
		*.GKO : Keep out layer mask - Used as outer boundary
		*.GTL : Top layer copper
		*.GTO : Top silkscreen 	
		*.GTP : Top Pad master mask
		*.GTS : Top Solder mask


/Paste/
	File containing top and bottom (if used) paste mask (*.GPT, *.GPB)

/Pick And Place/
	Pick and place file for this design (*.PIK)


/Placement/
	File with top placement drawing (*.pdf)
		
/Schematics/
	Schematics file (*.pdf)
